// app.config.ts
import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideIcons } from '@ng-icons/core';
import {
  tablerSchool,
  tablerLayoutDashboard,
  tablerUsers,
  tablerReceipt,
  tablerBook,
  tablerCalendarCheck,
  tablerSettings,
  tablerSun,
  tablerMoon,
  tablerLogout,
  tablerLock
} from '@ng-icons/tabler-icons';
import { routes } from './app.routes';
import { authInterceptor } from './core/interceptors/auth.interceptor';
import { sessionExpiredInterceptor } from './core/interceptors/session-expired.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(withInterceptors([authInterceptor, sessionExpiredInterceptor])),
    provideIcons({
      tablerSchool,
      tablerLayoutDashboard,
      tablerUsers,
      tablerReceipt,
      tablerBook,
      tablerCalendarCheck,
      tablerSettings,
      tablerSun,
      tablerMoon,
      tablerLogout,
      tablerLock
    })
  ]
};