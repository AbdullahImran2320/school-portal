import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ClassesService } from '../../students/services/classes.service';
import { VouchersService } from '../services/vouchers.service';
import { ClassDto } from '../../students/models/class.models';
import { FeeVoucher } from '../models/fee.models';
import { FeesNavComponent } from '../../../shared/components/fees-nav/fees-nav.component';
import { DatePipe, DecimalPipe } from '@angular/common';

const MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];

@Component({
  selector: 'app-vouchers',
  standalone: true,
  imports: [FormsModule, FeesNavComponent, DecimalPipe, DatePipe],
  templateUrl: './vouchers.component.html',
  styleUrl: './vouchers.component.scss'
})
export class VouchersComponent implements OnInit {
  private classesService = inject(ClassesService);
  private vouchersService = inject(VouchersService);

  monthNames = MONTH_NAMES;
  copyLabels = ['Bank Copy', 'School Copy', 'Parent Copy'];

  classes = signal<ClassDto[]>([]);
  selectedClassId = signal<number | null>(null);
  selectedMonth = signal(new Date().getMonth() + 1);
  selectedYear = signal(new Date().getFullYear());

  chargeTypes = signal<string[]>([]);
  selectedChargeType = signal<string | null>(null);
  admissionDateFrom = signal<string | null>(null);
  admissionDateTo = signal<string | null>(null);

  vouchers = signal<FeeVoucher[]>([]);
  loading = signal(false);
  error = signal<string | null>(null);

  // Which of the generated vouchers to actually show/print — defaults to
  // everyone, but lets the admin uncheck specific students without having
  // to re-run generation with narrower filters (charge type / admission
  // date only narrow WHO qualifies, they can't hand-pick individuals).
  selectedStudentIds = signal<Set<number>>(new Set());
  showStudentPicker = signal(false);

  visibleVouchers = computed(() =>
    this.vouchers().filter(v => this.selectedStudentIds().has(v.studentId))
  );

  yearOptions = computed(() => {
    const current = new Date().getFullYear();
    return [current - 1, current, current + 1];
  });

  ngOnInit() {
    this.classesService.getAll().subscribe({
      next: (data) => {
        this.classes.set(data);
        if (data.length > 0) this.onClassChange(data[0].classId);
      },
      error: () => this.error.set('Could not load classes.')
    });
  }

  onClassChange(classId: number) {
    this.selectedClassId.set(classId);
    this.selectedChargeType.set(null);
    this.vouchersService.getChargeTypesForClass(classId).subscribe({
      next: (types) => this.chargeTypes.set(types),
      error: () => this.chargeTypes.set([])
    });
  }

  loadVouchers() {
    const classId = this.selectedClassId();
    if (!classId) return;
    this.loading.set(true);
    this.error.set(null);
    this.vouchersService.getClassVouchers(classId, this.selectedMonth(), this.selectedYear(), {
      chargeType: this.selectedChargeType() ?? undefined,
      admissionDateFrom: this.admissionDateFrom() ?? undefined,
      admissionDateTo: this.admissionDateTo() ?? undefined
    }).subscribe({
      next: (data) => {
        this.vouchers.set(data);
        // Default to everyone selected — the picker is for narrowing down,
        // not an opt-in list someone has to rebuild from empty every time.
        this.selectedStudentIds.set(new Set(data.map(v => v.studentId)));
        this.loading.set(false);
      },
      error: () => { this.error.set('Could not load challans for this class/month.'); this.loading.set(false); }
    });
  }

  toggleStudent(studentId: number) {
    const current = new Set(this.selectedStudentIds());
    if (current.has(studentId)) current.delete(studentId);
    else current.add(studentId);
    this.selectedStudentIds.set(current);
  }

  isStudentSelected(studentId: number): boolean {
    return this.selectedStudentIds().has(studentId);
  }

  selectAllStudents() {
    this.selectedStudentIds.set(new Set(this.vouchers().map(v => v.studentId)));
  }

  selectNoStudents() {
    this.selectedStudentIds.set(new Set());
  }

  printAll() { window.print(); }
}
